#!/bin/bash

echo "Launching JesusGPT secure build + App Store integration..."
npm install -g eas-cli
eas whoami || eas login
eas init --non-interactive
eas credentials
eas build --platform all --profile production

echo "Build pushed to Expo."
